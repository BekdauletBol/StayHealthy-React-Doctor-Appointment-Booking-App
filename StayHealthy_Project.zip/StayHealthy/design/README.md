# Layout studies

The application includes three low-fidelity design boards:

- `/?design=navbar`
- `/?design=signup`
- `/?design=login`

These are original React-rendered layout studies, not exports from a supplied design file. The screenshots show the navbar hierarchy, form fields, supporting content and calls to action. The final interface implements these structures in a responsive teal-and-ivory visual system.
