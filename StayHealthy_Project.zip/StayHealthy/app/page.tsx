import StayHealthyApp from "./stayhealthy-app";
export default function Page() { return <StayHealthyApp/>; }
