import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "StayHealthy | Find a doctor & book an appointment",
  description: "Explore our React healthcare capstone: search demo doctors, book simulated appointments, manage your profile and share reviews.",
  metadataBase: new URL("https://stayhealthy-bekdaulet-capstone.rarebrink3.chatgpt.site"),
  alternates: {canonical: "/"},
  keywords: ["React capstone", "doctor search", "appointment booking", "StayHealthy"],
  twitter: {card: "summary", title: "StayHealthy — Good care, closer to you", description: "A full-stack React healthcare appointment simulation."},
  robots: {index: false, follow: false},
  openGraph: {title: "StayHealthy — Good care, closer to you", description: "A full-stack React appointment booking capstone by Bekdaulet Bolatov.", type: "website"},
  icons: {icon: "/favicon.svg"},
};
export default function RootLayout({children}: Readonly<{children: React.ReactNode}>) {
  return <html lang="en"><body>{children}</body></html>;
}
