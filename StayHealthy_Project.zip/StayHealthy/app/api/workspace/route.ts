import { headers } from 'next/headers';
import { eq } from 'drizzle-orm';
import { getDb } from '@/db';
import { workspaces } from '@/db/schema';

export const dynamic = 'force-dynamic';
type RecordItem = {id:string; [key:string]:any};
type Workspace = {profile:any; appointments:RecordItem[]; reviews:RecordItem[]; notifications:RecordItem[]; consultations:RecordItem[]};
const fresh = ():Workspace => ({profile:null,appointments:[],reviews:[],notifications:[],consultations:[]});
function fail(message:string,status=400){return Response.json({error:message},{status});}
async function owner(){const h=await headers();return h.get('oai-authenticated-user-id') || (process.env.NODE_ENV==='development'?'development-preview':null);}
async function read(id:string){const db=getDb();const rows=await db.select().from(workspaces).where(eq(workspaces.ownerId,id));return rows.length?JSON.parse(rows[0].data) as Workspace:fresh();}
async function write(id:string,data:Workspace){await getDb().insert(workspaces).values({ownerId:id,data:JSON.stringify(data)}).onConflictDoUpdate({target:workspaces.ownerId,set:{data:JSON.stringify(data)}});}
function clean(w:Workspace){return {...w,profile:w.profile?{name:w.profile.name,email:w.profile.email,phone:w.profile.phone}:null};}
async function digest(password:string,salt:string){const enc=new TextEncoder();const key=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveBits']);const bits=await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:enc.encode(salt),iterations:60000},key,256);return Array.from(new Uint8Array(bits),b=>b.toString(16).padStart(2,'0')).join('');}
function notify(w:Workspace,title:string,description:string){w.notifications.unshift({id:crypto.randomUUID(),title,description,read:false,createdAt:new Date().toISOString()});}
export async function GET(){try{const id=await owner();if(!id)return fail('Sign in with ChatGPT to open your workspace.',401);return Response.json(clean(await read(id)),{headers:{'Cache-Control':'no-store'}});}catch(e){console.error(e);return fail('The workspace is temporarily unavailable. Please retry.',503);}}
export async function POST(request:Request){try{
 const id=await owner();if(!id)return fail('Sign in with ChatGPT to continue.',401);
 const payload=await request.json();if(!payload||typeof payload!=="object"||Array.isArray(payload))return fail("Invalid request.");const body=payload as Record<string,unknown>;const w=await read(id);const action=body.action;
 if(action==='signup'){
  if(w.profile)return fail('A demo profile already exists. Please log in.',409);
  const name=String(body.name||'').trim(), email=String(body.email||'').trim().toLowerCase(), password=String(body.password||'');
  if(name.length<2)return fail('Enter your full name.');if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return fail('Enter a valid email address.');
  if(password.length<8||!/[a-zA-Z]/.test(password)||!/[0-9]/.test(password))return fail('Password needs at least 8 characters, a letter and a number.');
  const salt=crypto.randomUUID();w.profile={name,email,phone:String(body.phone||'').trim(),salt,passwordHash:await digest(password,salt)};
  notify(w,'Welcome to StayHealthy','Your demo profile is ready. Explore doctors to book a simulated visit.');
 }else if(action==='login'){
  if(!w.profile || String(body.email||'').trim().toLowerCase()!==w.profile.email || await digest(String(body.password||''),w.profile.salt)!==w.profile.passwordHash)return fail('Email or password is incorrect.',401);
  return Response.json(clean(w));
 }else if(action==='logout'){return Response.json({ok:true});}
 else {
  if(!w.profile)return fail('Create a demo profile first.',403);
  if(action==='profile'){
   const name=String(body.name||'').trim(),phone=String(body.phone||'').trim();
   if(name.length<2)return fail('Name must contain at least two characters.');
   if(phone&&!/^[+\d\s()-]{7,20}$/.test(phone))return fail('Enter a valid phone number.');
   w.profile.name=name;w.profile.phone=phone;
  }else if(action==='book'){
   const doctors=['sarah','james','maya'];const doctor=String(body.doctor), date=String(body.date),time=String(body.time);
   const today=new Date().toISOString().slice(0,10);
   if(!doctors.includes(doctor)||!/^\d{4}-\d{2}-\d{2}$/.test(date)||date<today||!['09:00','10:30','14:00','15:30'].includes(time))return fail('Choose a doctor, a future date and an available time.');
   if(w.appointments.some(a=>a.doctor===doctor&&a.date===date&&a.time===time&&a.status!=='Cancelled'))return fail('You already have this appointment.',409);
   w.appointments.unshift({id:crypto.randomUUID(),doctor,date,time,status:'Upcoming'});
   notify(w,'Appointment confirmed',`${body.doctorName || 'Your doctor'} · ${date} at ${time}. This is a simulated booking.`);
  }else if(action==='cancel'||action==='complete'){
   const a=w.appointments.find(a=>a.id===body.id);if(!a)return fail('Appointment not found.',404);
   if(a.status!=='Upcoming')return fail('Only upcoming appointments can be changed.');
   a.status=action==='cancel'?'Cancelled':'Completed';notify(w,action==='cancel'?'Appointment cancelled':'Demo visit completed',action==='cancel'?'Your simulated appointment was cancelled.':'You can now leave a review for this doctor.');
  }else if(action==='read-notifications'){w.notifications.forEach(n=>n.read=true);}
  else if(action==='review'){
   const appointment=w.appointments.find(a=>a.id===body.appointment&&a.status==='Completed');
   const rating=Number(body.rating),comment=String(body.comment||'').trim();
   if(!appointment)return fail('Choose a completed demo visit.');
   if(w.reviews.some(r=>r.appointment===appointment.id))return fail('This visit already has a review.',409);
   if(!Number.isInteger(rating)||rating<1||rating>5||comment.length<10||comment.length>500)return fail('Choose 1–5 stars and write 10–500 characters.');
   w.reviews.unshift({id:crypto.randomUUID(),appointment:appointment.id,doctor:appointment.doctor,rating,comment,author:w.profile.name,createdAt:new Date().toISOString()});
   notify(w,'Review published','Your feedback was saved in your demo workspace.');
  }else if(action==='consult'){
   const record={id:crypto.randomUUID(),status:'Requested',createdAt:new Date().toISOString()};w.consultations.unshift(record);
   notify(w,'Consultation request received','Demo request saved. No real clinician will be contacted.');
  }else return fail('Unknown action.');
 }
 await write(id,w);return Response.json(clean(w));
 }catch(e){console.error(e);return fail('Could not save your changes. Please try again.',500);}}
