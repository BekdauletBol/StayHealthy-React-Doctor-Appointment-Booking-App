# Что загрузить в Coursera

**Project Title:** StayHealthy — React Doctor Appointment Booking App

| Task | Файл из screenshots |
| --- | --- |
| 1 | navbar_design.png |
| 2 | signup_form_design.png |
| 3 | login_form_design.png |
| 4 | readme.md_file.png |
| 5 | signup_validation.png |
| 6 | login_validation.png |
| 7 | logout_button.png |
| 8 | docsearch_output.png |
| 9 | notification_integration.png |
| 10 | instant_consultation.png |
| 11 | disable_review-button.png |
| 12 | review_form.png |
| 13 | profilename_change.png |
| 14 | build.png |
| 15 | seo.png |

Task 16 требует реальную ссылку на новый GitHub-репозиторий этого проекта.
Task 17 требует ссылку на папку `screenshots` внутри того же репозитория.

Не используй репозиторий Little Lemon: это другой проект.

Если GitHub не подключён к чату, создай пустой репозиторий `stayhealthy-react-capstone`, распакуй исходники и загрузи содержимое папки проекта вместе с `screenshots`. В Terminal из этой папки:

```sh
git init
git add .
git commit -m "Build StayHealthy React healthcare capstone"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/stayhealthy-react-capstone.git
git push -u origin main
```

Замени YOUR_USERNAME своим именем GitHub. Указывай только фактический URL созданного репозитория. Ссылку на папку screenshots скопируй из браузера после её открытия в GitHub.

Сайт опубликован приватно. Его ссылка не заменяет GitHub-ссылки из Tasks 16–17. Преподавателю нужен доступ к исходникам в репозитории.

Скриншоты настоящие: они сняты с работающего приложения. Макеты созданы как отдельные дизайн-страницы; README, build и SEO показаны на страницах доказательств, сформированных из фактических файлов/лога сборки. Это новые материалы по рубрике, а не скриншоты выполнения оригинальных лабораторных в среде курса.

Проверь правила курса об использовании ИИ, изучи проект и самостоятельно прими Honor Code только если можешь честно подтвердить его условия.
