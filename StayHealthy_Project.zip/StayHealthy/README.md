# StayHealthy — React Healthcare Capstone

**Author: Bekdaulet Bolatov**

A full-stack React healthcare appointment simulation. It provides validated registration/login exercises, searchable demo doctors, appointment booking and cancellation, notifications, instant consultation requests, reviews and profile editing.

## Run locally

Requirements: Node.js 22.13+ and npm.

```sh
npm ci
npm run build
```

Apply the initial database migration, using the filename in `drizzle/`:

```sh
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_fat_nuke.sql
npm run dev
```

Use the actual generated SQL filename if it differs. The initial migration is already included; do not regenerate it unless changing the schema. Open the URL printed by the development server. On portable local development, `/signin-with-chatgpt?return_to=/` provides the starter's mock identity. Hosted identity is supplied by the platform.

## Components and features

- `app/stayhealthy-app.tsx`: React components, validation, navigation and all user flows.
- `app/api/workspace/route.ts`: server validation, profile storage and action handlers.
- `db/schema.ts` and `drizzle/`: persistent D1 database schema and migrations.
- `app/layout.tsx`: page title, description, Open Graph metadata and favicon.
- `screenshots/`: the 15 evidence images requested by the rubric.
- `design/`: layout studies and supporting design notes.

### Registration and login

Create a demo profile with a name, email and password (8+ characters with a letter and a number). Empty/invalid fields show inline errors. The server validates inputs independently and hashes the demo password with salted PBKDF2. Logout returns to the login form.

Hosted authentication and record ownership use the platform's ChatGPT identity. The email/password forms are a coursework exercise within that private workspace, not a separate production authentication provider. Only the signed-in platform owner can access their records. The "Open existing demo workspace" shortcut previews a profile already owned by your platform identity without entering demo credentials. A local browser flag controls the demo's logged-in view; it does not authorize server requests.

### Appointments and notifications

Search doctors by name, specialty or city. Choose a date and time to book a simulated appointment. Duplicate bookings in the same workspace are rejected. My appointments supports cancellation and marking a demo visit completed. Server-saved notifications confirm bookings, cancellations, consultations and reviews; Mark all read updates their state.

### Reviews and profiles

Only completed demo appointments can be reviewed, once per appointment. Submit remains disabled until an appointment, a star rating and a 10–500 character comment are provided. Profile changes persist on the server and update the header and profile card.

## Technology

React, TypeScript, Vinext (Next-compatible React routes), CSS, Lucide icons, Cloudflare Workers, D1 and Drizzle. The site is responsive and includes labeled fields, keyboard-visible focus, semantic forms, status announcements and reduced-motion support.

## Educational scope

All doctors and bookings are fictional. Consultation requests do not contact a real clinician. No real medical service, payment processing or medical advice is provided. Use test information only.

Reconstructed from the provided rubric with AI assistance; original course lab source/templates were not supplied. Review the course's assistance policy before submitting. Screenshots are captured from the running application and actual build/source evidence.

## Submission

Upload the 15 PNGs to Tasks 1–15 using their exact filenames. Task 16 requires a real GitHub repository URL. Task 17 requires that repository's `/tree/main/screenshots` URL. A deployment URL is not a substitute for the requested GitHub links. Do not use placeholder repository URLs.

## Private live demo

https://stayhealthy-bekdaulet-capstone.rarebrink3.chatgpt.site

The live demo is private. Reviewers should use the GitHub source and local run instructions unless access to the hosted demo is explicitly shared.
